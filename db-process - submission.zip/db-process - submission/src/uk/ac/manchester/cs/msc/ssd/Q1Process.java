package uk.ac.manchester.cs.msc.ssd;

import java.io.*;
import java.sql.*;
import java.util.*;

import org.apache.commons.csv.*;

import uk.ac.manchester.cs.msc.ssd.core.*;

//
// THIS CLASS IS A TEMPLATE WHOSE IMPLEMENTATION SHOULD BE PROVIDED
// BY THE STUDENT IN ORDER TO PROVIDE A SOLUTION TO PROBLEM 1.
//
// THE "ExampleProcess" CLASS SHOULD BE USED AS A GUIDE IN CREATING
// THE IMPLEMENTATION.
//
class Q1Process extends DatabaseProcess {
	
	static private final File ATTEMPTS_IN_FILE = getInputFile("attempts"); // *********
	static private final File PEOPLE_IN_FILE = getInputFile("people"); // *********
	static private final String ATTEMPTS_TABLE_NAME = "ATTEMPTS"; // ***********
	static private final String PEOPLE_TABLE_NAME = "PEOPLE"; // ***********
	
	static private final String ATTEMPTS_PERSON_ID_NAME = "PERSONID"; // ***********
	static private final String ATTEMPTS_PROBLEM_ID_NAME = "PROBLEMID"; // ***********
	static private final String ATTEMPTS_ANSWER_NAME = "ANSWER"; // ***********
	
	static private final String PEOPLE_PERSON_ID_NAME = "PERSONID"; // ***********
	static private final String PEOPLE_FIRSTNAME_NAME = "FIRSTNAME"; // ***********
	static private final String PEOPLE_SECONDNAME_NAME = "SECONDNAME"; // ***********
	static private final String PEOPLE_COMPANY_NAME = "COMPANY"; // ***********
	static private final String PEOPLE_ADDRESS_NAME = "ADDRESS"; // ***********
	static private final String PEOPLE_CITY_NAME = "CITY"; // ***********
	static private final String PEOPLE_COUNTY_NAME = "COUNTY"; // ***********
	static private final String PEOPLE_POSTAL_NAME = "POSTAL"; // ***********
	static private final String PEOPLE_PHONE1_NAME = "PHONE1"; // ***********
	static private final String PEOPLE_PHONE2_NAME = "PHONE2"; // ***********
	static private final String PEOPLE_EMAIL_NAME = "EMAIL"; // ***********
	static private final String PEOPLE_WEB_NAME = "WEB"; // ***********
	
	static private final String Q1_ANSWERED_NAME = "ANSWERED"; // **********
		
	static private final String ATTEMPTS_TABLE_CREATION_ARGS // ***********
	                     = ATTEMPTS_PERSON_ID_NAME + " integer NOT NULL, " // *********
						 + ATTEMPTS_PROBLEM_ID_NAME + " integer NOT NULL, " //*********
						 + ATTEMPTS_ANSWER_NAME + " integer NOT NULL"; // **********

	static private final String PEOPLE_TABLE_CREATION_ARGS // **********
						 = PEOPLE_PERSON_ID_NAME + " integer NOT NULL, " // *********
						 + PEOPLE_FIRSTNAME_NAME + " varchar(255), " // *********
						 + PEOPLE_SECONDNAME_NAME + " varchar(255), " // *********
						 + PEOPLE_COMPANY_NAME + " varchar(255), " // *********
						 + PEOPLE_ADDRESS_NAME + " varchar(255), " // *********
						 + PEOPLE_CITY_NAME + " varchar(255), " // *********
						 + PEOPLE_COUNTY_NAME + " varchar(255), " // *********
						 + PEOPLE_POSTAL_NAME + " varchar(255), " // *********
						 + PEOPLE_PHONE1_NAME + " varchar(255), " // *********
						 + PEOPLE_PHONE2_NAME + " varchar(255), " // *********
						 + PEOPLE_EMAIL_NAME + " varchar(255), " // *********
						 + PEOPLE_WEB_NAME + " varchar(255)"; // *********
						 
	static private final String SELECT_Q1_QUERY
						 = "SELECT SECONDNAME, FIRSTNAME, COUNT(*) AS ANSWERED " // **********
						 + "FROM PEOPLE, ATTEMPTS WHERE PEOPLE.PERSONID = ATTEMPTS.PERSONID " // **********
						 + "GROUP BY ATTEMPTS.PERSONID, SECONDNAME, FIRSTNAME"; // **********
	private Database database;
	private CSVHandler csvHandler;
	
	private InputTable peopleInputTable = new InputTable(); // ***********
	private InputTable attemptsInputTable = new InputTable(); // ***********
	
	private List<PersonAttempt> personattempts = new ArrayList<PersonAttempt>(); // **********
	private class PersonAttempt {                                         // **********
		private String lastname;                                        // **********
		private String firstname;                                      // **********
		private int attempts;                                        // **********
		
		public String toString() {                                  // **********
			return lastname + firstname + attempts;                // ***********
		}                                                         // ***********
		
		PersonAttempt(ResultSet results) throws SQLException {    // **********
			lastname = results.getString(PEOPLE_SECONDNAME_NAME); // **********
			firstname = results.getString(PEOPLE_FIRSTNAME_NAME); // **********
			attempts = results.getInt(Q1_ANSWERED_NAME);          // **********
			personattempts.add(this);                       // ************
			System.out.println("RETRIEVED: " + this);      // ***********
		}                                                 // ***********
		
		void print(CSVPrinter printer) throws IOException {     // *********
			printer.printRecord(lastname,firstname,attempts);  // **********
		}                                                     // **********
	}                                                        // **********
	

	// Implementation of the "readInput" method as specified by the base-class.
	protected void readInput() throws IOException {

		peopleInputTable.readFromFile(csvHandler, PEOPLE_IN_FILE);  // *********
		attemptsInputTable.readFromFile(csvHandler, ATTEMPTS_IN_FILE);  // *********
	}

	// Implementation of the "runCoreProcess" method as specified by the base-class.
	protected void runCoreProcess() throws SQLException {

		database.createTable(PEOPLE_TABLE_NAME,PEOPLE_TABLE_CREATION_ARGS);  // ********
		database.createTable(ATTEMPTS_TABLE_NAME, ATTEMPTS_TABLE_CREATION_ARGS);  // *********
		peopleInputTable.writeToDatabase(database,PEOPLE_TABLE_NAME); // *********
		attemptsInputTable.writeToDatabase(database,ATTEMPTS_TABLE_NAME);  // *********
		ResultSet results = database.executeQuery(SELECT_Q1_QUERY); // *********
		while (results.next()) {                                   // *********
			new PersonAttempt(results);                           // *********
		}                                                        // *********
	}                                                           // *********

	// Implementation of the "writeOutput" method as specified by the base-class.
	protected void writeOutput() throws IOException {

		File outCSVFile = getOutputFile();                            // *********
		CSVPrinter printer = csvHandler.createPrinter(outCSVFile);  // *********
		for (PersonAttempt personattempt : personattempts) {       // *********
			personattempt.print(printer);                         // *********
		}                                                        // *********
	}

	// Constructor.
	Q1Process(Database database, CSVHandler csvHandler) {

		this.database = database;
		this.csvHandler = csvHandler;
	}
}
