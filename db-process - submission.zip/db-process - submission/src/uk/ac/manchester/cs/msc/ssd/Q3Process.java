package uk.ac.manchester.cs.msc.ssd;

import java.io.*;
import java.sql.*;
import java.util.*;

import org.apache.commons.csv.*;

import uk.ac.manchester.cs.msc.ssd.core.*;

//
// THIS CLASS IS A TEMPLATE WHOSE IMPLEMENTATION SHOULD BE PROVIDED
// BY THE STUDENT IN ORDER TO PROVIDE A SOLUTION TO PROBLEM 1.
//
// THE "ExampleProcess" CLASS SHOULD BE USED AS A GUIDE IN CREATING
// THE IMPLEMENTATION.
//
class Q3Process extends DatabaseProcess {
	
	static private final File ATTEMPTS_IN_FILE = getInputFile("attempts"); // *********
	static private final File PROBLEMS_IN_FILE = getInputFile("problems"); // *********
	static private final String ATTEMPTS_TABLE_NAME = "ATTEMPTS"; // ***********
	static private final String PROBLEMS_TABLE_NAME = "PROBLEMS"; // ***********
	
	static private final String ATTEMPTS_PERSON_ID_NAME = "PERSONID"; // ***********
	static private final String ATTEMPTS_PROBLEM_ID_NAME = "PROBLEMID"; // ***********
	static private final String ATTEMPTS_ANSWER_NAME = "ANSWER"; // ***********
	
	static private final String PROBLEM_ID_NAME = "PROBLEMID"; // *********
	static private final String PROBLEM_OP_NAME = "OP"; // *********
	static private final String PROBLEM_ARG1_NAME = "ARG1"; // *********
	static private final String PROBLEM_ARG2_NAME = "ARG2"; // *********
	
	static private final String Q3_ID_NAME = "ID"; // *********
	static private final String Q3_ANSWERED_NAME = "ANSWERED"; // *********
	static private final String Q3_SUCCESSRATE_NAME = "SUCCESSRATE"; // *********
	
	static private final String ATTEMPTS_TABLE_CREATION_ARGS // ***********
	                     = ATTEMPTS_PERSON_ID_NAME + " integer NOT NULL, " // *********
						 + ATTEMPTS_PROBLEM_ID_NAME + " integer NOT NULL, " //*********
						 + ATTEMPTS_ANSWER_NAME + " integer NOT NULL"; // **********
	static private final String PROBLEMS_TABLE_CREATION_ARGS // **********
									= PROBLEM_ID_NAME + " integer NOT NULL, " // **********
									+ PROBLEM_ARG1_NAME + " integer NOT NULL, " // **********
									+ PROBLEM_OP_NAME + " char(1), " // **********
									+ PROBLEM_ARG2_NAME + " integer NOT NULL"; // **********

	static private final String SELECT_Q3_QUERY // **********
									= "SELECT ATTEMPTS.PROBLEMID AS ID,COUNT(*) AS ANSWERED, " // **********
									+ "SUM(CASE WHEN ANSWER= " // **********
									+ "(CASE WHEN OP = '+' THEN ARG1 + ARG2 WHEN OP = '-' THEN ARG1-ARG2 WHEN OP='*' THEN ARG1*ARG2 ELSE ARG1/ARG2 END)" // **********
									+ "THEN 1 ELSE 0 END)*100/COUNT(*) AS SUCCESSRATE " // **********
									+ "FROM ATTEMPTS,PROBLEMS " // **********
									+ "WHERE ATTEMPTS.PROBLEMID = PROBLEMS.PROBLEMID " // **********
									+ "GROUP BY ATTEMPTS.PROBLEMID"; // **********

	private Database database;
	private CSVHandler csvHandler;
	
	private InputTable problemsInputTable = new InputTable(); // ***********
	private InputTable attemptsInputTable = new InputTable(); // ***********
	
	private List<ProblemSuccess> problemsuccesses = new ArrayList<ProblemSuccess>(); // **********
	private class ProblemSuccess {                                         // **********
		private int question;                                        // **********
		private int attempts;                                      // **********
		private int successrate;                                        // **********
		
		public String toString() {                                  // **********
			return "" + question + attempts + successrate;                // ***********
		}                                                         // ***********
		
		ProblemSuccess(ResultSet results) throws SQLException {    // **********
			question = results.getInt(Q3_ID_NAME); // **********
			attempts = results.getInt(Q3_ANSWERED_NAME); // **********
			successrate = results.getInt(Q3_SUCCESSRATE_NAME); // **********
			problemsuccesses.add(this);                       // ************
			System.out.println("RETRIEVED: " + this);      // ***********
		}                                                 // ***********
		
		void print(CSVPrinter printer) throws IOException {     // *********
			printer.printRecord(question,attempts,successrate);  // **********
		} 
	}
	// Implementation of the "readInput" method as specified by the base-class.
	protected void readInput() throws IOException {

		problemsInputTable.readFromFile(csvHandler, PROBLEMS_IN_FILE);  // *********
		attemptsInputTable.readFromFile(csvHandler, ATTEMPTS_IN_FILE);  // *********
	}

	// Implementation of the "runCoreProcess" method as specified by the base-class.
	protected void runCoreProcess() throws SQLException {

		database.createTable(PROBLEMS_TABLE_NAME,PROBLEMS_TABLE_CREATION_ARGS);  // ********
		database.createTable(ATTEMPTS_TABLE_NAME, ATTEMPTS_TABLE_CREATION_ARGS);  // *********
		problemsInputTable.writeToDatabase(database,PROBLEMS_TABLE_NAME); // *********
		attemptsInputTable.writeToDatabase(database,ATTEMPTS_TABLE_NAME);  // *********
		ResultSet results = database.executeQuery(SELECT_Q3_QUERY); // *********
		while (results.next()) {                                   // *********
			new ProblemSuccess(results);                          // *********
		}                                                        // *********
	}                                                  

	// Implementation of the "writeOutput" method as specified by the base-class.
	protected void writeOutput() throws IOException {

		File outCSVFile = getOutputFile();                            // *********
		CSVPrinter printer = csvHandler.createPrinter(outCSVFile);  // *********
		for (ProblemSuccess problemsuccess : problemsuccesses) {       // *********
			problemsuccess.print(printer);                         // *********
		}                                                        // *********
	}

	// Constructor.
	Q3Process(Database database, CSVHandler csvHandler) {

		this.database = database;
		this.csvHandler = csvHandler;
	}
}
