package uk.ac.manchester.cs.msc.ssd;

import java.io.*;
import java.sql.*;
import java.util.*;

import org.apache.commons.csv.*;

import uk.ac.manchester.cs.msc.ssd.core.*;

//
// THIS CLASS IS A TEMPLATE WHOSE IMPLEMENTATION SHOULD BE PROVIDED
// BY THE STUDENT IN ORDER TO PROVIDE A SOLUTION TO PROBLEM 1.
//
// THE "ExampleProcess" CLASS SHOULD BE USED AS A GUIDE IN CREATING
// THE IMPLEMENTATION.
//
class Q2Process extends DatabaseProcess {
	static private final File ATTEMPTS_IN_FILE = getInputFile("attempts"); // *********
	static private final File PROBLEMS_IN_FILE = getInputFile("problems"); // *********
	static private final File PEOPLE_IN_FILE = getInputFile("people"); // *********
	static private final String ATTEMPTS_TABLE_NAME = "ATTEMPTS"; // ***********
	static private final String PROBLEMS_TABLE_NAME = "PROBLEMS"; // ***********
	static private final String PEOPLE_TABLE_NAME = "PEOPLE"; // ***********
	
	static private final String ATTEMPTS_PERSON_ID_NAME = "PERSONID"; // ***********
	static private final String ATTEMPTS_PROBLEM_ID_NAME = "PROBLEMID"; // ***********
	static private final String ATTEMPTS_ANSWER_NAME = "ANSWER"; // ***********
	
	static private final String PROBLEM_ID_NAME = "PROBLEMID"; // *********
	static private final String PROBLEM_OP_NAME = "OP"; // *********
	static private final String PROBLEM_ARG1_NAME = "ARG1"; // *********
	static private final String PROBLEM_ARG2_NAME = "ARG2"; // *********
	
	static private final String PEOPLE_PERSON_ID_NAME = "PERSONID"; // ***********
	static private final String PEOPLE_FIRSTNAME_NAME = "FIRSTNAME"; // ***********
	static private final String PEOPLE_SECONDNAME_NAME = "SECONDNAME"; // ***********
	static private final String PEOPLE_COMPANY_NAME = "COMPANY"; // ***********
	static private final String PEOPLE_ADDRESS_NAME = "ADDRESS"; // ***********
	static private final String PEOPLE_CITY_NAME = "CITY"; // ***********
	static private final String PEOPLE_COUNTY_NAME = "COUNTY"; // ***********
	static private final String PEOPLE_POSTAL_NAME = "POSTAL"; // ***********
	static private final String PEOPLE_PHONE1_NAME = "PHONE1"; // ***********
	static private final String PEOPLE_PHONE2_NAME = "PHONE2"; // ***********
	static private final String PEOPLE_EMAIL_NAME = "EMAIL"; // ***********
	static private final String PEOPLE_WEB_NAME = "WEB"; // ***********
	
	static private final String Q2_ANSWERED_NAME = "ANSWERED"; // *********
	static private final String Q2_PCANSWERED_NAME = "PCANSWERED"; // *********
	static private final String Q2_ANSWEREDCORRECTLY_NAME = "ANSWEREDCORRECTLY"; // *********
	static private final String Q2_PCANSWEREDCORRECTLY_NAME = "PCANSWEREDCORRECTLY"; // *********
	static private final String Q2_PCANSWEREDCORRECTLYFROMALL_NAME = "PCANSWEREDCORRECTLYFROMALL"; // *********
	
	static private final String ATTEMPTS_TABLE_CREATION_ARGS // ***********
	                     = ATTEMPTS_PERSON_ID_NAME + " integer NOT NULL, " // *********
						 + ATTEMPTS_PROBLEM_ID_NAME + " integer NOT NULL, " //*********
						 + ATTEMPTS_ANSWER_NAME + " integer NOT NULL"; // **********
	static private final String PROBLEMS_TABLE_CREATION_ARGS // **********
									= PROBLEM_ID_NAME + " integer NOT NULL, " // **********
									+ PROBLEM_ARG1_NAME + " integer NOT NULL, " // **********
									+ PROBLEM_OP_NAME + " char(1), " // **********
									+ PROBLEM_ARG2_NAME + " integer NOT NULL"; // **********
	static private final String PEOPLE_TABLE_CREATION_ARGS // **********
						 = PEOPLE_PERSON_ID_NAME + " integer NOT NULL, " // *********
						 + PEOPLE_FIRSTNAME_NAME + " varchar(255), " // *********
						 + PEOPLE_SECONDNAME_NAME + " varchar(255), " // *********
						 + PEOPLE_COMPANY_NAME + " varchar(255), " // *********
						 + PEOPLE_ADDRESS_NAME + " varchar(255), " // *********
						 + PEOPLE_CITY_NAME + " varchar(255), " // *********
						 + PEOPLE_COUNTY_NAME + " varchar(255), " // *********
						 + PEOPLE_POSTAL_NAME + " varchar(255), " // *********
						 + PEOPLE_PHONE1_NAME + " varchar(255), " // *********
						 + PEOPLE_PHONE2_NAME + " varchar(255), " // *********
						 + PEOPLE_EMAIL_NAME + " varchar(255), " // *********
						 + PEOPLE_WEB_NAME + " varchar(255)"; // *********

	static private final String SELECT_Q2_QUERY // **********
									= "SELECT SECONDNAME,FIRSTNAME,POSTAL,COUNT(*) AS ANSWERED, " // **********
									+ "COUNT(*)*100/MIN((SELECT COUNT(*) FROM PROBLEMS)) AS PCANSWERED, " // **********
									+ "SUM(CASE WHEN ANSWER= " // **********
									+ "(CASE WHEN OP = '+' THEN ARG1 + ARG2 WHEN OP = '-' THEN ARG1-ARG2 WHEN OP='*' THEN ARG1*ARG2 ELSE ARG1/ARG2 END)" // **********
									+ "THEN 1 ELSE 0 END) AS ANSWEREDCORRECTLY, " // **********
									+ "SUM(CASE WHEN ANSWER= " // **********
									+ "(CASE WHEN OP = '+' THEN ARG1 + ARG2 WHEN OP = '-' THEN ARG1-ARG2 WHEN OP='*' THEN ARG1*ARG2 ELSE ARG1/ARG2 END)" // **********
									+ "THEN 1 ELSE 0 END)*100/COUNT(*) AS PCANSWEREDCORRECTLY, " // **********
									+ "SUM(CASE WHEN ANSWER= " // **********
									+ "(CASE WHEN OP = '+' THEN ARG1 + ARG2 WHEN OP = '-' THEN ARG1-ARG2 WHEN OP='*' THEN ARG1*ARG2 ELSE ARG1/ARG2 END)" // **********
									+ "THEN 1 ELSE 0 END)*100/MIN((SELECT COUNT(*) FROM PROBLEMS)) AS PCANSWEREDCORRECTLYFROMALL " // **********
									+ "FROM ATTEMPTS,PROBLEMS,PEOPLE " // **********
									+ "WHERE ATTEMPTS.PROBLEMID = PROBLEMS.PROBLEMID " // **********
									+ "AND ATTEMPTS.PERSONID = PEOPLE.PERSONID " // **********
									+ "GROUP BY SECONDNAME, FIRSTNAME, POSTAL " // **********
									+ "ORDER BY POSTAL, PCANSWEREDCORRECTLY,PCANSWEREDCORRECTLYFROMALL"; // **********
	private Database database;
	private CSVHandler csvHandler;
	
	private InputTable problemsInputTable = new InputTable(); // ***********
	private InputTable attemptsInputTable = new InputTable(); // ***********
	private InputTable peopleInputTable = new InputTable(); // ***********
	
	private List<ProblemSuccess> problemsuccesses = new ArrayList<ProblemSuccess>(); // **********
	private class ProblemSuccess {                                         // **********
		private String lastname;                                        // **********
		private String firstname;                                      // **********
		private String postal;                                        // **********
		private int answered;                                        // **********
		private double pcanswered;                                   // **********
		private int answeredcorrectly;                               // **********
		private double pcansweredcorrectly;                          // **********
		private double pcansweredcorrectlyfromall;                   // **********
		
		public String toString() {                                  // **********
			return "" + lastname + firstname + postal + answered + pcanswered + answeredcorrectly + pcansweredcorrectly + pcansweredcorrectlyfromall;   // ***********
		}                                                         // ***********
		
		ProblemSuccess(ResultSet results) throws SQLException {    // **********
			lastname = results.getString(PEOPLE_SECONDNAME_NAME); // **********
			firstname = results.getString(PEOPLE_FIRSTNAME_NAME); // **********
			postal = results.getString(PEOPLE_POSTAL_NAME); // **********
			answered = results.getInt(Q2_ANSWERED_NAME); // **********
			pcanswered = results.getDouble(Q2_PCANSWERED_NAME); // **********
			answeredcorrectly = results.getInt(Q2_ANSWEREDCORRECTLY_NAME); // **********
			pcansweredcorrectly = results.getDouble(Q2_PCANSWEREDCORRECTLY_NAME); // **********
			pcansweredcorrectlyfromall = results.getDouble(Q2_PCANSWEREDCORRECTLYFROMALL_NAME); // **********
			problemsuccesses.add(this);                       // ************
			System.out.println("RETRIEVED: " + this);      // ***********
		}                                                 // ***********
		
		void print(CSVPrinter printer) throws IOException {     // *********
			printer.printRecord(lastname,firstname,postal,answered,pcanswered,answeredcorrectly,pcansweredcorrectly,pcansweredcorrectlyfromall);  // **********
		} 
	}

	// Implementation of the "readInput" method as specified by the base-class.
	protected void readInput() throws IOException {

		problemsInputTable.readFromFile(csvHandler, PROBLEMS_IN_FILE);  // *********
		attemptsInputTable.readFromFile(csvHandler, ATTEMPTS_IN_FILE);  // *********
		peopleInputTable.readFromFile(csvHandler, PEOPLE_IN_FILE); // **********
	}

	// Implementation of the "runCoreProcess" method as specified by the base-class.
	protected void runCoreProcess() throws SQLException {

		database.createTable(PROBLEMS_TABLE_NAME,PROBLEMS_TABLE_CREATION_ARGS);  // ********
		database.createTable(ATTEMPTS_TABLE_NAME, ATTEMPTS_TABLE_CREATION_ARGS);  // *********
		database.createTable(PEOPLE_TABLE_NAME, PEOPLE_TABLE_CREATION_ARGS);  // *********		
		problemsInputTable.writeToDatabase(database,PROBLEMS_TABLE_NAME); // *********
		attemptsInputTable.writeToDatabase(database,ATTEMPTS_TABLE_NAME);  // *********
		peopleInputTable.writeToDatabase(database,PEOPLE_TABLE_NAME);  // *********
		ResultSet results = database.executeQuery(SELECT_Q2_QUERY); // *********
		while (results.next()) {                                   // *********
			new ProblemSuccess(results);                          // *********
		}                                                        // *********
	}

	// Implementation of the "writeOutput" method as specified by the base-class.
	protected void writeOutput() throws IOException {

		File outCSVFile = getOutputFile();                            // *********
		CSVPrinter printer = csvHandler.createPrinter(outCSVFile);  // *********
		for (ProblemSuccess problemsuccess : problemsuccesses) {       // *********
			problemsuccess.print(printer);                         // *********
		}                                                        // *********
	}

	// Constructor.
	Q2Process(Database database, CSVHandler csvHandler) {

		this.database = database;
		this.csvHandler = csvHandler;
	}
}
